#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from matplotlib import pyplot as plt


# In[2]:


# DATASET PREPERATION:


# In[3]:


df=pd.read_csv(".//A2Q2Data_train.csv",)


# In[4]:


df.columns


# In[5]:


df.columns=[i for i in range(len(df.columns))]


# In[6]:


df


# In[7]:


#ANALYTICAL SOLUTION USING GEOMETRC VIEW OR LINEAR ALGEBRA:
#x=inverse(trans(A)A)*trans(A)*B


# In[8]:


A=np.matrix(df.iloc[:,:100])
B=np.matrix(df.iloc[:,100]).reshape(9999,1)


# In[9]:


print(A.shape)
print(B.shape)


# In[10]:


trans=A.transpose()


# In[11]:


trans.shape


# In[12]:


x=np.linalg.inv(trans*A)*trans*B


# In[13]:


x.shape


# In[14]:


x


# In[15]:


type(x)


# In[16]:


#Here x is the W_ml


# In[17]:


# Testing on the test data and reporting the SSE:


# In[18]:


df_test=pd.read_csv(".//A2Q2Data_test.csv",)


# In[19]:


df_test.columns=[i for i in range(101)]
df_test.columns


# In[20]:


df_test


# In[22]:


x_test=df_test.iloc[:,:100]
y_test=df_test.iloc[:,100]


# In[23]:


x_test


# In[24]:


y_test


# In[26]:


error=np.linalg.norm((np.matrix(x_test)*x)-np.matrix(y_test).reshape(499,1))


# In[27]:


print("Error",error)


# In[ ]:




