#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from matplotlib import pyplot as plt


# In[2]:


#Organising the dataset


# In[3]:


df=pd.read_csv(".//A2Q2Data_train.csv")


# In[4]:


df.columns=[i for i in range(101)]


# In[5]:


df


# In[6]:


# Gradient Descent


# In[7]:



def derivative(A,X,B):
    derivative=[]
    der_sum=np.sum(A*X-B)
    for i in range(len(X)):
        derivative.append(2*X[i,0]*der_sum/9999)
    derivative=np.matrix(derivative).reshape(100,1)
    return derivative


# In[8]:


X=np.random.rand(100,1)
A=np.matrix(df.iloc[:,:100])
B=np.matrix(df.iloc[:,100]).reshape(9999,1)
print(X.shape)
print(A.shape)
print(B.shape)
epoch=1000
alpha=0.001


# In[9]:


for i in range(epoch):
    gradient=derivative(A,X,B)
    X=X-(alpha*gradient)
print(X)


# In[10]:


W_ml=X


# In[12]:


X=np.random.rand(100,1)
l_2_norm=[]
for i in range(epoch):
    gradient=derivative(A,X,B)
    X=X-(alpha*gradient)
    values=np.linalg.norm(X-W_ml,ord=2)
    l_2_norm.append(values)


# In[13]:


l_2_norm


# In[14]:


fig = plt.figure(figsize=(4,4))
t=[i+1 for i in range(epoch)]
ax = fig.add_subplot(111, projection='3d')
ax.scatter(0,t,l_2_norm)


# In[ ]:


# It is  observed that the difference gradually decreases with each iteration of algorithm.

