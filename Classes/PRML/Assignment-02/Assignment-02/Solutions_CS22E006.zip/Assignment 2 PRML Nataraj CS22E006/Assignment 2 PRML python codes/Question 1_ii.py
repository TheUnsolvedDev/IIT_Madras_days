#!/usr/bin/env python
# coding: utf-8

# In[21]:


from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style
import pandas as pd
import random
from scipy.special import softmax
from scipy.stats import multivariate_normal
from scipy.stats import norm


# In[23]:


df=pd.read_csv('A2Q1.csv', sep=',',header=None)
data = df.values
X = np.reshape(data, (400, 50))


# In[26]:


class Gaussian:

    def __init__(self,X,j,iterate):
        self.iterate = iterate
        self.j = j
        self.X = X
        self.mu = None
        self.pi = None
        self.cov = None
        self.XY = None


    def run(self):
        self.reg_cov = 1e-6*np.identity(len(self.X[0]))
        x,y = np.meshgrid(np.sort(self.X[:,0]),np.sort(self.X[:,1]))
        self.XY = np.array([x.flatten(),y.flatten()]).T
           
                    
        """ Set the initial mu, covariance and pi values"""
        self.mu = np.random.randint(min(self.X[:,0]),max(self.X[:,0]),size=(self.j,len(self.X[0]))) # (n x m) dim matrix
        self.cov = np.zeros((self.j,len(X[0]),len(X[0]))) # (n x m x m) dim covariance matrix for each source
        for dim in range(len(self.cov)):
            np.fill_diagonal(self.cov[dim],5)

        self.pi = np.ones(self.j) / self.j

        log_likelihoods = []
                    
        for i in tqdm(range(self.iterate)):               
            """E Step"""
            r_ik = np.zeros((len(self.X),len(self.cov)))

            for m,co,p,r in zip(self.mu,self.cov,self.pi,range(len(r_ik[0]))):
                co+=self.reg_cov
                mn = multivariate_normal(mean=m,cov=co)
                r_ik[:,r] = p*mn.pdf(self.X) / np.sum([pi_k*multivariate_normal(mean=mu_k,cov=cov_k).pdf(X)                                                      for pi_k,mu_k,cov_k in zip(self.pi,self.mu,self.cov+self.reg_cov)],axis=0)

            """M Step"""
            # Calculate new mean & new covariance_matrice
            self.mu = []
            self.cov = []
            self.pi = []
            
            for k in range(len(r_ik[0])):
                m_k = np.sum(r_ik[:,k],axis=0)
                mu_k = (1/m_k)*np.sum(self.X*r_ik[:,k].reshape(len(self.X),1),axis=0)
                self.mu.append(mu_k)

                # Calculate and append the covariance matrix per source based on the new mean
                cov_k = ((1/m_k)*np.dot((np.array(r_ik[:,k]).reshape(len(self.X),1)*(self.X-mu_k)).T,(self.X-mu_k)))+self.reg_cov
                self.cov.append(cov_k)
                # Calculate and append pi_new
                pi_k = m_k / np.sum(r_ik)
                self.pi.append(pi_k)

            lh = np.sum([k*multivariate_normal(self.mu[i],self.cov[j]).pdf(X)                                                   for k,i,j in zip(self.pi,range(len(self.mu)),range(len(self.cov)))])
            llh = np.log(lh)
            log_likelihoods.append(llh)

            

        fig2 = plt.figure(figsize=(10,7))
        ax1 = fig2.add_subplot(111) 
        ax1.set_title('Log-Likelihood')
        ax1.plot(range(0,self.iterate,1),log_likelihoods)
        plt.xlabel("Iterations")
        plt.ylabel("Log likelihood value")
        plt.show()


# In[27]:


j = 4
Gaussian = Gaussian(X,j,100)     
Gaussian.run()


# In[ ]:




