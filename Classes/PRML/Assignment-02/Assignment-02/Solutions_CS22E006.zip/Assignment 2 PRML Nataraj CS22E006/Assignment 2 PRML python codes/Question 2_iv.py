#!/usr/bin/env python
# coding: utf-8

# In[53]:


from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from tqdm import tqdm


# In[54]:


df=pd.read_csv(".//A2Q2Data_train.csv")


# In[55]:


df.columns=[i for i in range(len(df.columns))]


# In[56]:


df


# In[57]:


df.columns


# In[58]:



def derivative(A,X,B,lmbd):
    derivative_list=[]
    for i in range(len(X)):
        error=A*X-B
        error_mat=np.transpose(A[:,i])*error
        der_sum=np.sum(error_mat)
        derivative_list.append(2*der_sum+2*lmbd*int(X[i,0]))
    derivative=np.matrix(derivative_list).reshape(100,1)
    return derivative
        


# In[59]:


lamb_da=np.linspace(0,0.3,5)
epoch=1000
alpha=0.1
lambda_error=[]
X_list=[]
# Cross Validation
for l in lamb_da:
    df_c=df.sample(frac=1)
    X=np.random.rand(100,1)
    A_train,A_test=np.matrix(df_c.iloc[:8000,:100]),np.matrix(df_c.iloc[8000:,:100])
    B_train,B_test=np.matrix(df_c.iloc[:8000,100]), np.matrix(df_c.iloc[8000:,100])
    for i in tqdm(range(epoch)):
        gradient=derivative(A_train,X,B_train,l)
        X=X-(alpha*gradient)
    X_list.append(X)
    lambda_error.append(np.linalg.norm(A_test*X-B_test, ord=2))
index=np.argmin(lambda_error)
W_R=X_list[index]
lambda_optimal=lamb_da[index]
print("W_r",W_R)
print("lambda",lambda_optimal)

        


# In[65]:


plt.plot(lamb_da,lambda_error,color="green")
plt.xlabel("Lambda")
plt.ylabel("Validation Error")
plt.show()


# In[66]:


#Importing test data set:
df_test=pd.read_csv(".//A2Q2Data_test.csv",)
df_test.columns=[i for i in range(101)]
df_test.columns


# In[67]:


df_test


# In[68]:


x_test=df_test.iloc[:,:100]
y_test=df_test.iloc[:,100]


# In[69]:


# Importing test error:
Error_w_ml= 13.614527124310232
Error_w_r=np.linalg.norm((np.matrix(x_test)*W_R)-np.matrix(y_test).reshape(499,1))


# In[70]:


Error_w_r


# In[71]:


# Thus ridge regression better converges with lower error, thanks to the regularization parameter.

