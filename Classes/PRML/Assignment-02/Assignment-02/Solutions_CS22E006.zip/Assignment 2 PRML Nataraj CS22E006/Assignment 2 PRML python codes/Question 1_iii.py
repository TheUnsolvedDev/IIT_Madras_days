#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import matplotlib.pyplot as plt


# In[3]:


def KMEANS_CLUST(X,k,plot=False,T=1000):
    global error

    # Number of data points
    n = X.shape[0]

    # Initialization
    dist = np.zeros((k,n))
    z = np.zeros((n,))
    means = X[np.random.choice(n,size=k,replace=False),:] 
  
    converged = 1
    i=0
    while i < T and converged > 0:
        # Update labels 
        old_labels = z.copy()
        for j in range(k):
            dist[j,:] = np.sum((X - means[j,:])**2,axis=1) # L2 Norm
        z = np.argmin(dist,axis=0)
        error.append(z)

        # Check for Convergence
        converged = np.sum(z != old_labels)

        # Update means 
        for j in range(k):
            means[j,:] = np.mean(X[z==j,:],axis=0)

        # Iterate counter
        i+=1

    print("Number of iterations: ", i)
    # error.append(z)
    # error = dist
    
    return z


# In[4]:


data = np.genfromtxt('./A2Q1.csv', delimiter=',')


# In[7]:


error = []
X = data
K = 4
KMEANS_labels = KMEANS_CLUST(X,K,plot=True)
error_avg = np.sum(np.array(error), axis=1) / np.array(error).shape[1]


# In[6]:


# print(error)
plt.title('KMEANS CLUSTERING')
plt.xlabel('INITILIZATION NUMBER')
plt.ylabel('SUM OF SQUARED ERROR')
plt.plot(error_avg)
plt.show()


# In[ ]:




