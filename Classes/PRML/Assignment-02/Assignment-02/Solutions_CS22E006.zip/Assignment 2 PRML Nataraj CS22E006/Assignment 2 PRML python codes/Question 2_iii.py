#!/usr/bin/env python
# coding: utf-8

# In[12]:


from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from tqdm import tqdm


# In[13]:


df=pd.read_csv(".//A2Q2Data_train.csv")


# In[14]:


df.columns=[i for i in range(len(df.columns))]


# In[15]:


df


# In[16]:


df.columns


# In[20]:


Batch_size=100
def Stochastic_derivative(A,X,B):
    batch_no=0
    der_list=[]
    for i in range(0,len(df),Batch_size):
        batch_no+=1
        error=A[i:i+100,:]*X-B[i:i+100,:]
        der_sum=np.sum(error)
        derivative=[]
        for k in range(len(X)):
            derivative.append(2*X[k,0]*der_sum/Batch_size)
        derivative=np.matrix(derivative).reshape(100,1)
        der_list.append(derivative)
    deriv_final=sum(der_list)/batch_no
    return deriv_final
    


# In[24]:


X=np.random.rand(100,1)
A=np.matrix(df.iloc[:,:100])
B=np.matrix(df.iloc[:,100]).reshape(9999,1)
print(X.shape)
print(A.shape)
print(B.shape)
epoch=1000
alpha=0.01


# In[25]:


for i in tqdm(range(epoch)):
    gradient=Stochastic_derivative(A,X,B)
    X=X-(alpha*gradient)
print(X)


# In[26]:


W_ml=X


# In[27]:


X=np.random.rand(100,1)
l_2_norm=[]
for i in tqdm(range(epoch)):
    gradient=Stochastic_derivative(A,X,B)
    X=X-(alpha*gradient)
    values=np.linalg.norm(X-W_ml,ord=2)
    l_2_norm.append(values)


# In[29]:


print(l_2_norm)


# In[28]:


fig = plt.figure(figsize=(4,4))
t=[i+1 for i in range(epoch)]
ax = fig.add_subplot(111, projection='3d')
ax.scatter(0,t,l_2_norm)


# In[ ]:




