#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from numpy import log
from scipy.special import logsumexp
import matplotlib
import matplotlib.pyplot as plt
from itertools import product

get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


class BMM:

    def __init__(self, clus=4, iteration=100, tol=1e-8, alpha1=1e-6, alpha2=1e-6):
        self._clus = clus
        self._iteration = iteration
        self._tol = tol
        self._alpha1 = alpha1
        self._alpha2 = alpha2
        
        self.Pi = 1/self._clus*np.ones(self._clus)

    def _P(self, x, Mu, Pi):
        ll = np.dot(x,log(Mu))+np.dot(1-x,log(1-Mu))
        Z = (log(Pi)+ ll - logsumexp(ll+log(Pi), axis=1, keepdims=True))
        return Z

    def fit(self, data):
        global LogLikelihood
        self._n_samples, self._n_features = data.shape
        self.Mu = np.random.uniform(.25, .75, size=self._clus*self._n_features).reshape(self._n_features, self._clus)
        N = self._n_samples

        for i in range(self._iteration):
            exp = np.exp(self._P(data, self.Mu, self.Pi)) 
            W = exp/exp.sum(axis=1,keepdims=True)
            R = np.dot(data.transpose(), W)
            Q = np.sum(W, axis=0, keepdims=True)
            LogLikelihood.append(Q)
            # print("Shape: ", W.shape, R.shape, Q)
            
            
            self._oldPi = self.Pi
            
            self.Mu = (R + self._alpha1)/(Q + self._n_features*self._alpha1)
            self.Pi = (Q + self._alpha2)/(N + self._clus * self._alpha2)
            
            if np.allclose(self._oldPi, self.Pi):
                return
            


# In[16]:


if __name__ == "__main__":
    LogLikelihood = []
    data = np.genfromtxt("A2Q1.csv", delimiter=',')
    model = BMM(clus=4)
    model.fit(data)
    avg = np.divide(np.sum(LogLikelihood, axis=0), 100)
    print(avg)
    plt.plot(avg.T)
    plt.xlabel("Cluster/100 iteration")
    plt.ylabel("Average loglikelihood")
    plt.show()


# In[ ]:





# In[ ]:




