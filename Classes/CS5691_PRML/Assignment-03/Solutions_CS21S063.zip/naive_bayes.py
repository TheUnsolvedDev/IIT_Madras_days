# Naive Bayes
from init import *
vectorizer = CountVectorizer(stop_words='english')
test_vectorizer = CountVectorizer(stop_words='english')
email = vectorizer.fit_transform(raw_df.email.to_list())
label_encoder = sk.preprocessing.LabelEncoder()
labels = label_encoder.fit_transform(raw_df.label)
X_train,X_test,y_train,y_test = train_test_split(email,labels,train_size=0.8,random_state=42,shuffle=True)
X_train = X_train.toarray()
X_test = X_test.toarray()
y_train = y_train.reshape((-1,1))
y_test = y_test.reshape((-1,1))
X_test_ = test_vectorizer.fit_transform(read_test_emails()).toarray()
X_test_mod = np.zeros((X_test_.shape[0],X_train.shape[1]))
dict_train = vectorizer.vocabulary_
dict_test = test_vectorizer.vocabulary_
for key in dict_train.keys():
    if key in dict_test.keys():
#         print(f"train:{dict_train[key]},test:{dict_test[key]}")
        X_test_mod[:,dict_train[key]] = X_test_[:,dict_test[key]]
class NaiveBayes:
    def fit(self,X,Y):
        spam_count = np.sum(Y)
        ham_count = Y.shape[0] - spam_count
        P_spam = np.zeros((1,X.shape[1]))
        P_ham = np.zeros((1,X.shape[1]))
        for i in range(Y.shape[0]):
            boolidx = X[i,:] > 0
            if Y[i,:] == 1:
                P_spam = P_spam + 1*boolidx
            else:
                P_ham = P_ham + 1*boolidx 
        P_hat = spam_count/Y.shape[0]
        P_spam = P_spam/spam_count
        P_ham = P_ham/ham_count
        t = np.log((1-P_spam)/(1-P_ham))
        self.b = 0
        for x in t[0]:
            if not np.isnan(x):
                self.b += x
        self.b += np.log(P_hat/(1 - P_hat))
        self.W = np.log((P_spam*(1-P_ham))/(P_ham*(1-P_spam)))
    def predict(self,X_test):
        valindex = np.where(np.isfinite(self.W[0,:]))[0]
        X_test_bool = 1*(X_test > 0)
        Y_pred =  X_test_bool[:,valindex] @ self.W[:,valindex].T + self.b
        Y_pred[Y_pred > 0] = 1
        Y_pred[Y_pred <= 0] = 0
        return Y_pred
model = NaiveBayes()
model.fit(X_train,y_train)
Y_pred = model.predict(X_test)

#Validation accuracy
acc = np.sum(Y_pred == y_test)/Y_pred.shape[0]
print(f"Accuracy : {acc}")
#Predictions of emails in test folder
Y_pred = model.predict(X_test_mod)
print(Y_pred)
