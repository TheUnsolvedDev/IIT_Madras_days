# importing system libraries
import os
from os import walk
from string import punctuation
import random
from collections import Counter

# importing additional libraries
import numpy as np
import matplotlib.pyplot as plt
from striprtf.striprtf import rtf_to_text
plt.rcParams['figure.figsize'] = (20,10)
import pandas as pd
import sklearn as sk
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer,CountVectorizer
from sklearn.model_selection import train_test_split

# !kaggle datasets download -d wanderfj/enron-spam
# !unzip -o enron-spam.zip -d enron-data
# nltk.download()

def read_test_emails():
    testwalk = walk("test/")
    emails = []
    for root,dr,files in testwalk:
#         print(f"{root},{dr},{files}")
        for file in files:
            if "email"  in file:
    #             print(file)
                with open(root + file) as infile:
                    content = infile.read()
                    text = rtf_to_text(content)
                emails.append(text)
    return emails


pathwalk = walk("enron-data/")
SpamData,HamData = [],[]
for root,dr,files in pathwalk:
    if "spam" in str(files):
        for file in files:
            with open(root + '/' + file,encoding='latin1') as ip:
                SpamData.append(" ".join(ip.readlines()))
    if "ham" in str(files):
        for file in files:
            with open(root + '/' + file,encoding='latin1') as ip:
                HamData.append(" ".join(ip.readlines()))
SpamData = list(set(SpamData))
HamData = list(set(HamData))
Data = SpamData + HamData
Labels = ["spam"]*len(SpamData) + ["ham"]*len(HamData)
raw_df = pd.DataFrame({
    "email":Data,
    "label":Labels
})
