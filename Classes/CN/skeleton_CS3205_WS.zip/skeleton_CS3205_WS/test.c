#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void send_response(int client_socket, const char *response)
{
    send(client_socket, response, strlen(response), 0);
}

void handle_get_request(int client_socket, const char *path)
{
    char response[BUFFER_SIZE];
    if (strcmp(path, "/") == 0 || strcmp(path, "/index.html") == 0)
    {
        const char *html_content = "<html><head><title>Home</title></head><body><h1>Welcome!</h1></body></html>";
        sprintf(response, "HTTP/1.1 200 OK\r\nContent-Length: %zu\r\nContent-Type: text/html\r\n\r\n%s", strlen(html_content), html_content);
    }
    else
    {
        const char *not_found_msg = "<html><head><title>Not Found</title></head><body><h1>404 Not Found</h1></body></html>";
        sprintf(response, "HTTP/1.1 404 Not Found\r\nContent-Length: %zu\r\nContent-Type: text/html\r\n\r\n%s", strlen(not_found_msg), not_found_msg);
    }
    send_response(client_socket, response);
}

void handle_post_request(int client_socket, const char *data)
{
    // Handle POST data here
    printf("Received POST data: %s\n", data);

    const char *response_msg = "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n";
    send_response(client_socket, response_msg);
}

void handle_request(int client_socket, const char *request)
{
    char method[10];
    char path[256];

    sscanf(request, "%s %s", method, path);

    if (strcmp(method, "GET") == 0)
    {
        handle_get_request(client_socket, path);
    }
    else if (strcmp(method, "POST") == 0)
    {
        char *data_pos = strstr(request, "\r\n\r\n");
        if (data_pos != NULL)
        {
            data_pos += strlen("\r\n\r\n");
            handle_post_request(client_socket, data_pos);
        }
    }
    else
    {
        const char *not_supported_msg = "HTTP/1.1 501 Not Implemented\r\nContent-Length: 0\r\n\r\n";
        send_response(client_socket, not_supported_msg);
    }
}

int main()
{
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1)
    {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    int opt = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1)
    {
        perror("Error binding socket");
        exit(EXIT_FAILURE);
    }

    if (listen(server_socket, 5) == -1)
    {
        perror("Error listening for connections");
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", PORT);

    while (1)
    {
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_len);
        if (client_socket == -1)
        {
            perror("Error accepting connection");
            continue;
        }

        printf("Connection accepted from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        char buffer[BUFFER_SIZE];
        ssize_t bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
        if (bytes_received > 0)
        {
            buffer[bytes_received] = '\0';
            printf("Received request:\n%s\n", buffer);

            handle_request(client_socket, buffer);
        }
        close(client_socket);
    }
    close(server_socket);

    return 0;
}
